import numpy as np
import torch.nn as nn
import torch.distributed as dist

from operations import NaiveBN, ABN
from retrain_model.aspp import ASPP
from retrain_model.decoder import Decoder
from retrain_model.new_model import get_default_arch, newModel

class Retrain_Autodeeplab(nn.Module):
    def __init__(self, args):
        super(Retrain_Autodeeplab, self).__init__()
        filter_param_dict = {0: 1, 1: 2, 2: 4, 3: 8}
        BatchNorm2d = ABN if args.use_ABN else NaiveBN
        print('args.use_ABN: ', args.use_ABN)
        if (not args.dist and args.use_ABN) or (args.dist and args.use_ABN and dist.get_rank() == 0):
            print("=> use ABN!")
        print('args.net_arch: ', args.net_arch)
        print('args.net_path: ', args.net_path)
        print('args.cell_arch: ', args.cell_arch)
        if args.net_arch is not None and args.net_path is not None and args.cell_arch is not None:
            network_arch, cell_arch, network_path = np.load(args.net_arch), np.load(args.cell_arch), np.load(args.net_path)
            print('cell_arch:\n', cell_arch)
            print('network_path:\n', network_path)  # 0：4, 1：8, 2：16, 3：32。
        else:
            raise ValueError('No network arch / cell arch loaded')
            network_arch, cell_arch, network_path = get_default_arch()

        step = args.step
        self.encoder = newModel(network_arch, cell_arch, args.nclass, network_arch.shape[0], args.filter_multiplier, BatchNorm=BatchNorm2d, args=args, step=step)
        self.aspp = ASPP(args.filter_multiplier * args.block_multiplier * filter_param_dict[network_path[-1]],
                         256, args.nclass, conv=nn.Conv2d, norm=BatchNorm2d)

        if network_path[2] == 0:
            low_level_feat_channels = args.filter_multiplier * args.block_multiplier
        elif network_path[2] == 1:
            low_level_feat_channels = 2 * args.filter_multiplier * args.block_multiplier
        elif network_path[2] == 2:
            low_level_feat_channels = 4 * args.filter_multiplier * args.block_multiplier
        elif network_path[2] == 3:
            low_level_feat_channels = 8 * args.filter_multiplier * args.block_multiplier

        self.decoder = Decoder(args.nclass, filter_multiplier=low_level_feat_channels,
                               args=args,
                               last_level=network_path[-1])

    def forward(self, x):
        encoder_output, low_level_feature = self.encoder(x)
        high_level_feature = self.aspp(encoder_output)
        decoder_output = self.decoder(high_level_feature, low_level_feature)
        return nn.Upsample((x.shape[2], x.shape[3]), mode='bilinear', align_corners=True)(decoder_output)

    def get_params(self):
        back_bn_params, back_no_bn_params = self.encoder.get_params()
        tune_wd_params = list(self.aspp.parameters()) \
                         + list(self.decoder.parameters()) \
                         + back_no_bn_params
        no_tune_wd_params = back_bn_params
        return tune_wd_params, no_tune_wd_params