"""
The args of Pol-NAS in the search stage.
"""

import argparse
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "0"    # which GPU we plan to use

def obtain_search_args():
    parser = argparse.ArgumentParser(description="PyTorch Pol-NAS search stage")
    parser.add_argument('--backbone', type=str, default='mobilenet',
                        choices=['resnet', 'xception', 'drn', 'mobilenet'],
                        help='backbone name (default: mobilenet)')
    parser.add_argument('--opt_level', type=str, default='O0',
                        choices=['O0', 'O1', 'O2', 'O3'],
                        help='opt level for half percision training (default: O0)')
    # parser.add_argument('--out-stride', type=int, default=16,
    #                     help='network output stride (default: 8)')
    parser.add_argument('--dataset', type=str, default='oberpfaffenhofen',
                        choices=['oberpfaffenhofen', 'flevoland_rs2_1000_1300', 'sanfrancisco2'],
                        help='dataset name (default: oberpfaffenhofen)')
    parser.add_argument('--nclass', type=int, default=3,
                        help='the number of classes of the dataset, ob:3, fle_rs2_1000_1300:4, sf2:5')
    parser.add_argument('--data_augmentation', type=bool, default=True, help='whether to do data augmentation')
    parser.add_argument('--autodeeplab', type=str, default='search',
                        choices=['search', 'train'])
    # parser.add_argument('--use-sbd', action='store_true', default=False,
    #                     help='whether to use SBD dataset (default: True)')
    parser.add_argument('--load-parallel', type=int, default=0)
    parser.add_argument('--clean-module', type=int, default=0)
    parser.add_argument('--workers', type=int, default=0,
                        metavar='N', help='dataloader threads')
    # parser.add_argument('--base_size', type=int, default=128,
    #                     help='base image size')
    # parser.add_argument('--crop_size', type=int, default=128,
    #                     help='crop image size')
    # parser.add_argument('--resize', type=int, default=128,
    #                     help='resize image size')
    parser.add_argument('--patch_size', type=int, default=128,
                        help='image patch size')
    parser.add_argument('--height', type=int, default=1300,
                        help='whole image height')
    parser.add_argument('--width', type=int, default=1200,
                        help='whole image width')
    parser.add_argument('--stride', type=int, default=32,
                        help='the stride for producing two adjacent image patches')
    # parser.add_argument('--sync-bn', type=bool, default=None,
    #                     help='whether to use sync bn (default: auto)')
    parser.add_argument('--sync-bn', type=bool, default=True,
                        help='whether to use sync bn (default: auto)')
    parser.add_argument('--freeze-bn', type=bool, default=False,
                        help='whether to freeze bn parameters (default: False)')
    parser.add_argument('--loss-type', type=str, default='ce',
                        choices=['ce', 'focal'],
                        help='loss func type (default: ce)')
    # training hyper params
    # parser.add_argument('--epochs', type=int, default=None, metavar='N',
    #                     help='number of epochs to train (default: auto)')
    parser.add_argument('--epochs', type=int, default=80, metavar='N',
                        help='number of epochs to train (default: auto)')
    parser.add_argument('--start_epoch', type=int, default=0,
                        metavar='N', help='start epochs (default:0)')
    parser.add_argument('--alpha_epoch', type=int, default=20,
                        metavar='N', help='epoch to start training alphas')
    # parser.add_argument('--alpha_epoch', type=int, default=1,
    #                     metavar='N', help='epoch to start training alphas')
    parser.add_argument('--alpha_search_epoch_interval', type=int, default=10,
                        metavar='N', help='the epoch interval of two arch parameters searched and updated')
    parser.add_argument('--filter_multiplier', type=int, default=6)
    parser.add_argument('--block_multiplier', type=int, default=3)
    parser.add_argument('--step', type=int, default=3)
    parser.add_argument('--batch_size', type=int, default=16,
                        metavar='N', help='input batch size for \
                                training (default: auto)')
    parser.add_argument('--val_batch_size', type=int, default=512,
                        metavar='N', help='input batch size for \
                                validation (default: auto)')
    parser.add_argument('--use_balanced_weights', action='store_true', default=False,
                        help='whether to use balanced weights (default: False)')
    # optimizer params
    parser.add_argument('--lr', type=float, default=0.025, metavar='LR',
                        help='learning rate (default: auto)')
    parser.add_argument('--min_lr', type=float, default=0.001)
    parser.add_argument('--arch_lr', type=float, default=0.001, metavar='LR',
                        help='learning rate for alpha and beta in architect searching process')

    parser.add_argument('--lr_scheduler', type=str, default='cos',
                        choices=['poly', 'step', 'cos', 'no_decay'],
                        help='lr scheduler mode')
    parser.add_argument('--momentum', type=float, default=0.9,
                        metavar='M', help='momentum (default: 0.9)')
    parser.add_argument('--weight_decay', type=float, default=3e-4,
                        metavar='M', help='w-decay (default: 5e-4)')
    parser.add_argument('--arch_weight_decay', type=float, default=1e-3,
                        metavar='M', help='w-decay (default: 5e-4)')

    parser.add_argument('--nesterov', action='store_true', default=False,
                        help='whether use nesterov (default: False)')
    # cuda, seed and logging
    parser.add_argument('--no_cuda', action='store_true',
                        default=False, help='disables CUDA training')
    parser.add_argument('--use_amp', action='store_true', default=False)
    # parser.add_argument('--gpu_ids', type=str, default='1',
    #                     help='use which gpu to train, must be a \
    #                         comma-separated list of integers only (default=0)')
    parser.add_argument('--gpu_ids', type=str, default='0',
                        help='use which gpu to train, must be a \
                                comma-separated list of integers only (default=0)')
    parser.add_argument('--seed', type=int, default=1, metavar='S',
                        help='random seed (default: 1)')
    # checking point
    parser.add_argument('--resume', type=str, default=None,
                        help='put the path to resuming file if needed')
    # parser.add_argument('--resume', type=str, default='./run/pascal/deeplab-mobilenet/model_best.pth.tar',
    #                     help='put the path to resuming file if needed')
    parser.add_argument('--checkname', type=str, default=None,
                        help='set the checkpoint name')
    # finetuning pre-trained models
    parser.add_argument('--ft', action='store_true', default=False,
                        help='finetuning on a different dataset')
    # evaluation option
    parser.add_argument('--eval_interval', type=int, default=1,
                        help='evaluuation interval (default: 1)')
    parser.add_argument('--no_val', action='store_true', default=False,
                        help='skip validation during training')
    parser.add_argument('--affine', default=False,
                        type=bool, help='whether use affine in BN')
    # parser.add_argument('--multi_scale', default=(0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0),
    #                     type=bool, help='whether use multi_scale in train')
    parser.add_argument('--dist', default=False, type=bool, help='train in distributed way')
    # parser.add_argument('--use_dist', default=False, type=bool, help='train in distributed way')
    parser.add_argument('--weight_loss_list', default=[], type=list, help='a list to record the training weight loss.')
    parser.add_argument('--arch_loss_list', default=[], type=list, help='a list to record the training architecture loss.')
    parser.add_argument('--acc_list', default=[], type=list, help='a list to record the overall accuracy of test set.')
    parser.add_argument('--kappa_list', default=[], type=list, help='a list to record the kappa of test set.')
    args = parser.parse_args()
    return args
