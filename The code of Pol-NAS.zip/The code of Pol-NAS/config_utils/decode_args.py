"""
The args of decoding the searched architecture of Pol-NAS.
"""

import argparse

def obtain_decode_args():
    parser = argparse.ArgumentParser(description="PyTorch Pol-NAS Arch Decoding")
    parser.add_argument('--backbone', type=str, default='mobilenet',
                        choices=['resnet', 'xception', 'drn', 'mobilenet'],
                        help='backbone name (default: resnet)')
    # parser.add_argument('--dataset', type=str, default='cityscapes',
    #                     choices=['pascal', 'coco', 'cityscapes', 'kd'],
    #                     help='dataset name (default: pascal)')
    parser.add_argument('--dataset', type=str, default='oberpfaffenhofen',
                        choices=['oberpfaffenhofen', 'flevoland_rs2_1000_1300', 'sanfrancisco2'],
                        help='dataset name (default: oberpfaffenhofen)')
    parser.add_argument('--autodeeplab', type=str, default='train',
                        choices=['search', 'train'])
    parser.add_argument('--filter_multiplier', type=int, default=8)
    parser.add_argument('--block_multiplier', type=int, default=3)
    parser.add_argument('--step', type=int, default=3)
    parser.add_argument('--batch_size', type=int, default=8,
                        metavar='N', help='input batch size for \
                                    training (default: auto)')
    parser.add_argument('--test_batch_size', type=int, default=None,
                        metavar='N', help='input batch size for \
                                testing (default: auto)')
    parser.add_argument('--no_cuda', action='store_true', default=False, help='disables CUDA training')
    parser.add_argument('--resume', type=str, default='./run/oberpfaffenhofen/deeplab-mobilenet/model_best.pth.tar',
                        help='put the path to resuming file if needed')
    return parser.parse_args()
