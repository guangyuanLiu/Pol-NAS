"""
The args of training the searched architecture of Pol-NAS.
"""

import argparse

def obtain_retrain_Pol_NAS_args():
    parser = argparse.ArgumentParser(description="PyTorch Pol-NAS Train Stage")
    parser.add_argument('--train', action='store_true', default=True, help='training mode')
    parser.add_argument('--exp', type=str, default='bnlr7e-3', help='name of experiment')
    parser.add_argument('--gpu', type=str, default='0', help='test time gpu device id')
    parser.add_argument('--backbone', type=str, default='autodeeplab', help='resnet101')
    parser.add_argument('--dataset', type=str, default='oberpfaffenhofen',
                        choices=['oberpfaffenhofen', 'flevoland_rs2_1000_1300', 'sanfrancisco2'],
                        help='dataset name (default: oberpfaffenhofen)')
    parser.add_argument('--nclass', type=int, default=3,
                        help='the number of classes of the dataset, ob:3, flevoland_rs2:4, sf2:5')
    parser.add_argument('--groups', type=int, default=None, help='num of groups for group normalization')
    parser.add_argument('--epochs', type=int, default=100, help='num of training epochs')
    parser.add_argument('--batch_size', type=int, default=16, help='batch size')
    parser.add_argument('--test_batch_size', type=int, default=128, help='test batch size')
    parser.add_argument('--base_lr', type=float, default=0.001, help='base learning rate')
    parser.add_argument('--warmup_start_lr', type=float, default=5e-6, help='warm up learning rate')
    parser.add_argument('--lr-step', type=float, default=None)
    parser.add_argument('--warmup_iters', type=int, default=100)
    parser.add_argument('--min_lr', type=float, default=None)
    # parser.add_argument('--last_mult', type=float, default=1.0, help='learning rate multiplier for last layers')
    parser.add_argument('--scratch', action='store_true', default=False, help='train from scratch')
    parser.add_argument('--freeze_bn', action='store_true', default=False, help='freeze batch normalization parameters')
    parser.add_argument('--weight_std', action='store_true', default=False, help='weight standardization')
    parser.add_argument('--beta', action='store_true', default=False, help='resnet101 beta')
    parser.add_argument('--patch_size', type=int, default=128,help='image patch size')
    parser.add_argument('--height', type=int, default=1300, help='whole image height')
    parser.add_argument('--width', type=int, default=1200, help='whole image width')
    parser.add_argument('--stride', type=int, default=32, help='the stride for producing two adjacent image patches')
    parser.add_argument('--data_augmentation', type=bool, default=True, help='whether to do data augmentation')
    parser.add_argument('--workers', type=int, default=4, help='number of data loading workers')
    parser.add_argument('--seed', type=int, default=1, metavar='S', help='random seed (default: 1)')
    parser.add_argument('--resume', type=str, default=None, help='put the path to resuming file if needed')
    parser.add_argument('--filter_multiplier', type=int, default=8)
    parser.add_argument('--step', type=int, default=3)
    parser.add_argument('--dist', type=bool, default=False)
    parser.add_argument('--autodeeplab', type=str, default='train')
    parser.add_argument('--block_multiplier', type=int, default=3)
    parser.add_argument('--use_ABN', default=False, type=bool, help='whether use ABN')
    # parser.add_argument('--affine', default=False, type=bool, help='whether use affine in BN')
    parser.add_argument('--affine', default=True, type=bool, help='whether use affine in BN')
    parser.add_argument('--port', default=6000, type=int)
    parser.add_argument('--max-iteration', default=1000000, type=bool)
    # the directory of the searched architecture
    base_dir = '...'
    parser.add_argument('--net_arch', default=base_dir + '/network_path_space.npy', type=str)
    parser.add_argument('--net_path', default=base_dir + '/network_path.npy', type=str)
    parser.add_argument('--cell_arch', default=base_dir + '/genotype.npy', type=str)
    parser.add_argument('--criterion', default='ce', type=str)
    parser.add_argument('--initial_fm', default=None, type=int)
    # parser.add_argument('--mode', default='poly', type=str, help='how lr decline')
    parser.add_argument('--mode', default='no_decay', type=str, help="how lr decline, {'cos', 'poly', 'step', 'no_decay'}")
    parser.add_argument('--local_rank', dest='local_rank', type=int, default=-1, )
    parser.add_argument('--train_mode', type=str, default='iter', choices=['iter', 'epoch'])

    args = parser.parse_args()
    return args
