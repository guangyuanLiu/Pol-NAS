"""
The program for decoding the searched architecture of Pol-NAS.
"""

import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"    # which GPU we plan to use
import numpy as np
from modeling.deeplab import *
from decoding_formulas import Decoder
from config_utils.decode_args import obtain_decode_args


class Loader(object):
    def __init__(self, args):
        self.args = args
        if self.args.dataset == 'cityscapes':
            self.nclass = 19
        elif self.args.dataset == 'pascal':
            self.nclass = 21
        elif self.args.dataset == 'oberpfaffenhofen':
            self.nclass = 3
        elif self.args.dataset == 'flevoland_rs2_1000_1300':
            self.nclass = 4
        elif self.args.dataset == 'sanfrancisco2':
            self.nclass = 5

        # Resuming checkpoint
        self.best_pred = 0.0

        assert args.resume is not None, RuntimeError("No model to decode in resume path: '{:}'".format(args.resume))
        assert os.path.isfile(args.resume), RuntimeError("=> no checkpoint found at '{}'".format(args.resume))

        checkpoint = torch.load(args.resume)

        args.start_epoch = checkpoint['epoch']
        self._layer_num_param = checkpoint['state_dict']['layer_num_param']
        self._alphas = checkpoint['state_dict']['alphas']
        self._betas = checkpoint['state_dict']['betas']

        self.best_layer_num = torch.argmax(self._layer_num_param)
        if self.best_layer_num == 0:
            self.best_layer_num = 6
        elif self.best_layer_num == 1:
            self.best_layer_num = 8
        else:
            self.best_layer_num = 10

        print('args.start_epoch: ', args.start_epoch)
        print('self.best_layer_num: ', self.best_layer_num)
        print('self._alphas: \n', self._alphas)
        print('self._alphas.shape: ', self._alphas.shape)
        print('self._betas: \n', self._betas)
        print('self._betas.shape: ', self._betas.shape)

        # self.decoder = Decoder(alphas=self._alphas, betas=self._betas, steps=5)
        if self.best_layer_num == 6:
            self.decoder = Decoder(alphas=self._alphas, betas=self._betas[:6, :, :], steps=args.step)
        elif self.best_layer_num == 8:
            self.decoder = Decoder(alphas=self._alphas, betas=self._betas[:8, :, :], steps=args.step)
        else:
            self.decoder = Decoder(alphas=self._alphas, betas=self._betas, steps=args.step)

    def retreive_alphas_betas(self):
        return self._alphas, self._betas

    def decode_architecture(self):
        paths, paths_space = self.decoder.viterbi_decode()
        return paths, paths_space, self.best_layer_num

    def decode_cell(self):
        genotype = self.decoder.genotype_decode()
        return genotype


def get_new_network_cell():
    # feature_name_list = ['T9', 'H/alpha/A', 'λ1/λ2/λ3', 'TSVM_decomp', 'Pauli_decomp_dB', 'Huynen_decomp_dB',
    #                      'Holm1_decomp_dB', 'Holm2_decomp_dB', 'Freeman2_decomp_dB', 'Freeman3_decomp_dB',
    #                      'Cloude_decomp_dB', 'Barnes1_decomp_dB', 'Barnes2_decomp_dB', 'An_Yang3_decomp_dB',
    #                      'An_Yang4_decomp_dB', 'Yamaguchi3_decomp_dB', 'Yamaguchi4_decomp_dB', 'VanZyl3_decomp_dB',
    #                      'MCSM_decomp_dB', 'SPAN', 'theta_null', 'ABCDEF']  # all input features

    args = obtain_decode_args()
    args.cuda = not args.no_cuda and torch.cuda.is_available()
    load_model = Loader(args)
    result_paths, result_paths_space, result_layer_num = load_model.decode_architecture()
    network_layer_num = result_layer_num
    network_path = result_paths
    network_path_space = result_paths_space
    genotype = load_model.decode_cell()

    print('network_layer_num:\n', network_layer_num)
    print('architecture search results:\n', network_path)
    print('new cell structure:\n', genotype)

    dir_name = os.path.dirname(args.resume)
    network_layer_num_filename = os.path.join(dir_name, 'network_layer_num')

    network_path_filename = os.path.join(dir_name, 'network_path')
    network_path_space_filename = os.path.join(dir_name, 'network_path_space')
    genotype_filename = os.path.join(dir_name, 'genotype')

    np.save(network_layer_num_filename, network_layer_num)
    np.save(network_path_filename, network_path)
    np.save(network_path_space_filename, network_path_space)
    np.save(genotype_filename, genotype)

    print('saved to :', dir_name)


if __name__ == '__main__':
    get_new_network_cell()
