from dataloaders.datasets import cityscapes, kd, coco, combine_dbs, pascal, sbd
from torch.utils.data import DataLoader, Dataset
import torch.utils.data.distributed
import struct
import numpy as np

class data_process():
    def write_data(self, filename, data):
        fw = open(filename, "wb")
        for i in data:
            s = struct.pack('f', i)
            fw.write(s)
        fw.close()
    def read_data(self, filename, data):
        fr = open(filename, 'rb')
        unbytes = struct.unpack('{}f'.format(len(data)), fr.read())
        return unbytes

data_p = data_process()

def read_data_patch_loader(data_dir, data_p=data_p):
    data_len = [0] * 128 * 128 * 77
    data_patch = data_p.read_data(data_dir, data_len)
    data_patch = np.array(data_patch)
    data_patch = data_patch.reshape([77, 128, 128])

    return data_patch

def read_mask_train_A_patch_loader(mask_dir, data_p=data_p):
    mask_len = [0] * 128 * 128
    mask_train_A_patch = data_p.read_data(mask_dir, mask_len)
    mask_train_A_patch = np.array(mask_train_A_patch, dtype=np.bool)
    mask_train_A_patch = mask_train_A_patch.reshape([128, 128])

    return mask_train_A_patch

def read_mask_train_B_patch_loader(mask_dir, data_p=data_p):
    mask_len = [0] * 128 * 128
    mask_train_B_patch = data_p.read_data(mask_dir, mask_len)
    mask_train_B_patch = np.array(mask_train_B_patch, dtype=np.bool)
    mask_train_B_patch = mask_train_B_patch.reshape([128, 128])

    return mask_train_B_patch

def read_gt_patch_loader(gt_dir, data_p=data_p):
    gt_len = [0] * 128 * 128
    gt_patch = data_p.read_data(gt_dir, gt_len)
    gt_patch = np.array(gt_patch, dtype=np.int32)
    gt_patch = gt_patch.reshape([128, 128])

    return gt_patch


class AutoPolFCN_train_A(Dataset):
    def __init__(self, data_path_list, mask_A_path_list, gt_path_list, data_loader=read_data_patch_loader,
                 mask_A_loader=read_mask_train_A_patch_loader, gt_loader=read_gt_patch_loader):
        self.data_path_list = data_path_list
        self.mask_A_path_list = mask_A_path_list
        self.gt_path_list = gt_path_list
        self.data_loader = data_loader
        self.mask_A_loader = mask_A_loader
        self.gt_loader = gt_loader

    def __getitem__(self, index):
        data_path = self.data_path_list[index]
        data_patch = self.data_loader(data_path)

        mask_A_path = self.mask_A_path_list[index]
        mask_train_A_patch = self.mask_A_loader(mask_A_path)

        gt_path = self.gt_path_list[index]
        gt_patch = self.gt_loader(gt_path)
        gt_ones = np.ones(gt_patch.shape)
        gt_patch = gt_patch - gt_ones

        data_patch = torch.FloatTensor(data_patch)

        return data_patch, mask_train_A_patch, gt_patch

    def __len__(self):
        return len(self.data_path_list)

class AutoPolFCN_train_B(Dataset):
    def __init__(self, data_path_list, mask_B_path_list, gt_path_list, data_loader=read_data_patch_loader,
                 mask_B_loader=read_mask_train_B_patch_loader, gt_loader=read_gt_patch_loader):
        self.data_path_list = data_path_list
        self.mask_B_path_list = mask_B_path_list
        self.gt_path_list = gt_path_list
        self.data_loader = data_loader
        self.mask_B_loader = mask_B_loader
        self.gt_loader = gt_loader

    def __getitem__(self, index):
        data_path = self.data_path_list[index]
        data_patch = self.data_loader(data_path)

        mask_B_path = self.mask_B_path_list[index]
        mask_train_B_patch = self.mask_B_loader(mask_B_path)

        gt_path = self.gt_path_list[index]
        gt_patch = self.gt_loader(gt_path)
        gt_ones = np.ones(gt_patch.shape)
        gt_patch = gt_patch - gt_ones

        data_patch = torch.FloatTensor(data_patch)

        return data_patch, mask_train_B_patch, gt_patch

    def __len__(self):
        return len(self.data_path_list)

class AutoPolFCN_data_patch(Dataset):
    def __init__(self, data_path_list, loader=read_data_patch_loader):
        self.data_path_list = data_path_list
        self.loader = loader

    def __getitem__(self, index):
        data_path = self.data_path_list[index]
        data_patch = self.loader(data_path)
        data_patch = torch.FloatTensor(data_patch)
        return data_patch

    def __len__(self):
        return len(self.data_path_list)

class AutoPolFCN_train_AB(Dataset):
    def __init__(self, data_path_list, mask_A_path_list, mask_B_path_list, gt_path_list, data_loader=read_data_patch_loader,
                 mask_A_loader=read_mask_train_A_patch_loader, mask_B_loader=read_mask_train_B_patch_loader,
                 gt_loader=read_gt_patch_loader):
        self.data_path_list = data_path_list
        self.mask_A_path_list = mask_A_path_list
        self.mask_B_path_list = mask_B_path_list
        self.gt_path_list = gt_path_list
        self.data_loader = data_loader
        self.mask_A_loader = mask_A_loader
        self.mask_B_loader = mask_B_loader
        self.gt_loader = gt_loader

    def __getitem__(self, index):
        data_path = self.data_path_list[index]
        data_patch = self.data_loader(data_path)

        mask_A_path = self.mask_A_path_list[index]
        mask_train_A_patch = self.mask_A_loader(mask_A_path)

        mask_B_path = self.mask_B_path_list[index]
        mask_train_B_patch = self.mask_B_loader(mask_B_path)

        gt_path = self.gt_path_list[index]
        gt_patch = self.gt_loader(gt_path)
        gt_ones = np.ones(gt_patch.shape)
        gt_patch = gt_patch - gt_ones

        data_patch = torch.FloatTensor(data_patch)

        return data_patch, mask_train_A_patch+mask_train_B_patch, gt_patch

    def __len__(self):
        return len(self.data_path_list)

def make_data_loader(args, **kwargs):
    if args.dist:
        print("=> Using Distribued Sampler")
        if args.dataset == 'cityscapes':
            if args.autodeeplab == 'search':
                train_set1, train_set2 = cityscapes.twoTrainSeg(args)
                num_class = train_set1.NUM_CLASSES
                sampler1 = torch.utils.data.distributed.DistributedSampler(train_set1)
                sampler2 = torch.utils.data.distributed.DistributedSampler(train_set2)
                train_loader1 = DataLoader(train_set1, batch_size=args.batch_size, shuffle=False, sampler=sampler1, **kwargs)
                train_loader2 = DataLoader(train_set2, batch_size=args.batch_size, shuffle=False, sampler=sampler2, **kwargs)

            elif args.autodeeplab == 'train':
                train_set = cityscapes.CityscapesSegmentation(args, split='retrain')
                num_class = train_set.NUM_CLASSES
                sampler1 = torch.utils.data.distributed.DistributedSampler(train_set)
                train_loader = DataLoader(train_set, batch_size=args.batch_size, shuffle=False, sampler=sampler1, **kwargs)

            else:
                raise Exception('autodeeplab param not set properly')

            val_set = cityscapes.CityscapesSegmentation(args, split='val')
            test_set = cityscapes.CityscapesSegmentation(args, split='test')
            sampler3 = torch.utils.data.distributed.DistributedSampler(val_set)
            sampler4 = torch.utils.data.distributed.DistributedSampler(test_set)
            val_loader = DataLoader(val_set, batch_size=args.batch_size, shuffle=False, sampler=sampler3, **kwargs)
            test_loader = DataLoader(test_set, batch_size=args.batch_size, shuffle=False, sampler=sampler4, **kwargs)

            if args.autodeeplab == 'search':
                return train_loader1, train_loader2, val_loader, test_loader, num_class
            elif args.autodeeplab == 'train':
                return train_loader, num_class, sampler1
        else:
            raise NotImplementedError

    else:
        if args.dataset == 'oberpfaffenhofen':
            HEIGHT = 1300
            WIDTH = 1200

            if args.autodeeplab == 'search':
                base_dir = '/media/lgy/extra/PolSAR_image/Oberpfaffenhofen/train_AB_test_AutoPolFCN_feat_select_zscore_0.01'
                # not filtered
                # base_dir = '/media/lgy/extra/PolSAR_image/Oberpfaffenhofen/not_filter_train_AB_test_AutoPolFCN_feat_select_zscore_0.01'
            else:
                base_dir = '/media/lgy/extra/PolSAR_image/Oberpfaffenhofen/train_AB_test_AutoPolFCN_feat_select_for_train_0.1_val_zscore_0.01'
                # not filtered
                # base_dir = '/media/lgy/extra/PolSAR_image/Oberpfaffenhofen/not_filter_train_AB_test_AutoPolFCN_feat_select_for_train_0.1_val_zscore_0.01'

            STRIDE = 32  # the distance between two adjacent patches
            PATCH_SIZE = 128

            # ====== Calculate HEIGHT_AFTER_PAD and WIDTH_AFTER_PAD =======
            if ((HEIGHT - PATCH_SIZE) % STRIDE) != 0:
                num_of_rows_padding = STRIDE - ((HEIGHT - PATCH_SIZE) % STRIDE)
                HEIGHT_AFTER_PAD = HEIGHT + num_of_rows_padding
            else:
                HEIGHT_AFTER_PAD = HEIGHT

            if ((WIDTH - PATCH_SIZE) % STRIDE) != 0:
                num_of_cols_padding = STRIDE - ((WIDTH - PATCH_SIZE) % STRIDE)
                WIDTH_AFTER_PAD = WIDTH + num_of_cols_padding
            else:
                WIDTH_AFTER_PAD = WIDTH

            print('HEIGHT_AFTER_PAD: ', HEIGHT_AFTER_PAD)
            print('WIDTH_AFTER_PAD: ', WIDTH_AFTER_PAD)

            PATCH_ROW_NUM = int((HEIGHT_AFTER_PAD - PATCH_SIZE) / STRIDE + 1)
            PATCH_COL_NUM = int((WIDTH_AFTER_PAD - PATCH_SIZE) / STRIDE + 1)
            PATCH_NUM = PATCH_ROW_NUM * PATCH_COL_NUM  # the number of patches we have
            print('PATCH_NUM: ', PATCH_NUM)

            # ==================== load the data ========================
            data_p = data_process()

            mask_val_len = [0] * HEIGHT_AFTER_PAD * WIDTH_AFTER_PAD
            mask_test_len = [0] * HEIGHT_AFTER_PAD * WIDTH_AFTER_PAD
            gt_test_len = [0] * HEIGHT_AFTER_PAD * WIDTH_AFTER_PAD

            data_patch_dir_list = []
            data_patch_dir_list_not_aug = []
            mask_train_A_patch_dir_list = []
            mask_train_B_patch_dir_list = []
            gt_patch_dir_list = []

            for i in range(PATCH_ROW_NUM):
                for j in range(PATCH_COL_NUM):
                    # Oberpfaffenhofen
                    data_patch_dir_list.append(base_dir + '/data_patch/Oberpfaffenhofen ' + str(
                        i) + 'th_row ' + str(j) + ' th_col patch.bin')
                    mask_train_A_patch_dir_list.append(base_dir + '/mask_train_A_patch/Oberpfaffenhofen ' + str(
                        i) + 'th_row ' + str(j) + ' th_col_mask_train_A_patch.bin')
                    mask_train_B_patch_dir_list.append(base_dir + '/mask_train_B_patch/Oberpfaffenhofen ' + str(
                        i) + 'th_row ' + str(j) + ' th_col_mask_train_B_patch.bin')
                    gt_patch_dir_list.append(base_dir + '/gt_patch/Oberpfaffenhofen ' + str(
                        i) + 'th_row ' + str(j) + ' th_col_ground_truth_patch.bin')

                    data_patch_dir_list_not_aug.append(base_dir + '/data_patch/Oberpfaffenhofen ' + str(
                        i) + 'th_row ' + str(j) + ' th_col patch.bin')

                    if args.data_augmentation:
                        # Oberpfaffenhofen
                        # horizontally flipped
                        data_patch_dir_list.append(base_dir + '/data_patch_lr_aug/Oberpfaffenhofen ' + str(
                            i) + 'th_row ' + str(j) + ' th_col patch_lr_flip.bin')
                        mask_train_A_patch_dir_list.append(
                            base_dir + '/mask_train_A_patch_lr_aug/Oberpfaffenhofen ' + str(
                                i) + 'th_row ' + str(j) + ' th_col_mask_train_A_patch_lr_flip.bin')
                        mask_train_B_patch_dir_list.append(
                            base_dir + '/mask_train_B_patch_lr_aug/Oberpfaffenhofen ' + str(
                                i) + 'th_row ' + str(j) + ' th_col_mask_train_B_patch_lr_flip.bin')
                        gt_patch_dir_list.append(base_dir + '/gt_patch_lr_aug/Oberpfaffenhofen ' + str(
                            i) + 'th_row ' + str(j) + ' th_col_ground_truth_patch_lr_flip.bin')
                        #
                        # vertically flipped
                        data_patch_dir_list.append(base_dir + '/data_patch_ud_aug/Oberpfaffenhofen ' + str(
                            i) + 'th_row ' + str(j) + ' th_col patch_ud_flip.bin')
                        mask_train_A_patch_dir_list.append(
                            base_dir + '/mask_train_A_patch_ud_aug/Oberpfaffenhofen ' + str(
                                i) + 'th_row ' + str(j) + ' th_col_mask_train_A_patch_ud_flip.bin')
                        mask_train_B_patch_dir_list.append(
                            base_dir + '/mask_train_B_patch_ud_aug/Oberpfaffenhofen ' + str(
                                i) + 'th_row ' + str(j) + ' th_col_mask_train_B_patch_ud_flip.bin')
                        gt_patch_dir_list.append(base_dir + '/gt_patch_ud_aug/Oberpfaffenhofen ' + str(
                            i) + 'th_row ' + str(j) + ' th_col_ground_truth_patch_ud_flip.bin')

            if args.autodeeplab == 'search':
                train_A_set = AutoPolFCN_train_A(data_patch_dir_list, mask_train_A_patch_dir_list, gt_patch_dir_list)
                train_A_loader = DataLoader(train_A_set, batch_size=args.batch_size, shuffle=True, drop_last=False,
                                               num_workers=4)
                train_B_set = AutoPolFCN_train_B(data_patch_dir_list, mask_train_B_patch_dir_list, gt_patch_dir_list)
                train_B_loader = DataLoader(train_B_set, batch_size=args.batch_size, shuffle=True, drop_last=False,
                                            num_workers=4)

                data_patch_set = AutoPolFCN_data_patch(data_patch_dir_list_not_aug)
                data_patch_loader = DataLoader(data_patch_set, batch_size=args.val_batch_size, shuffle=False,
                                               drop_last=False,
                                               num_workers=4)
                mask_val_whole_pic = data_p.read_data(
                    base_dir + '/Oberpfaffenhofen_mask_val_whole_pic.bin', mask_val_len)
                mask_test_whole_pic = data_p.read_data(
                    base_dir + '/Oberpfaffenhofen_mask_test_whole_pic.bin', mask_test_len)
                ground_truth = data_p.read_data(
                    base_dir + '/Oberpfaffenhofen_ground_truth_padding.bin', gt_test_len)

            elif args.autodeeplab == 'train':
                train_A_set = AutoPolFCN_train_A(data_patch_dir_list, mask_train_A_patch_dir_list, gt_patch_dir_list)
                train_A_loader = DataLoader(train_A_set, batch_size=args.batch_size, shuffle=True, drop_last=False,
                                            num_workers=4)

                data_patch_set = AutoPolFCN_data_patch(data_patch_dir_list_not_aug)
                data_patch_loader = DataLoader(data_patch_set, batch_size=args.test_batch_size, shuffle=False,
                                               drop_last=False,
                                               num_workers=4)

                mask_val_whole_pic = data_p.read_data(
                    base_dir + '/Oberpfaffenhofen_mask_val_whole_pic.bin', mask_val_len)
                mask_test_whole_pic = data_p.read_data(
                    base_dir + '/Oberpfaffenhofen_mask_test_whole_pic.bin', mask_test_len)
                ground_truth = data_p.read_data(
                    base_dir + '/Oberpfaffenhofen_ground_truth_padding.bin', gt_test_len)

            mask_val_whole_pic = np.array(mask_val_whole_pic, dtype=np.bool)
            mask_test_whole_pic = np.array(mask_test_whole_pic, dtype=np.bool)
            ground_truth = np.array(ground_truth, dtype=np.int32)
            mask_val_whole_pic = mask_val_whole_pic.reshape([HEIGHT_AFTER_PAD, WIDTH_AFTER_PAD])
            mask_test_whole_pic = mask_test_whole_pic.reshape([HEIGHT_AFTER_PAD, WIDTH_AFTER_PAD])
            ground_truth = ground_truth.reshape([HEIGHT_AFTER_PAD, WIDTH_AFTER_PAD])

            mask_val_whole_pic = mask_val_whole_pic[0:HEIGHT, 0:WIDTH]
            mask_test_whole_pic = mask_test_whole_pic[0:HEIGHT, 0:WIDTH]
            ground_truth = ground_truth[0:HEIGHT, 0:WIDTH]
            ground_truth = ground_truth - np.ones(ground_truth.shape)  # the label range is [0, TYPES-1] not [1, TYPES]

            mask_test_whole_pic = torch.from_numpy(mask_test_whole_pic)
            ground_truth = torch.from_numpy(ground_truth)
            print('========== data loading finished ==========')

            # return train_A_loader, train_B_loader, mask_val_whole_pic, mask_test_whole_pic, ground_truth, data_patch_loader  # for search stage
            return train_A_loader, mask_val_whole_pic, mask_test_whole_pic, ground_truth, data_patch_loader  # for training stage

        else:
            raise NotImplementedError

if __name__ == "__main__":
    from config_utils.search_args import obtain_search_args
    args = obtain_search_args()
    kwargs = {'num_workers': args.workers, 'pin_memory': True, 'drop_last': True}
    data_patch, mask_train_A_patch, mask_train_B_patch, gt_patch, mask_val_whole_pic, \
        mask_test_whole_pic, ground_truth = make_data_loader(args, **kwargs)


