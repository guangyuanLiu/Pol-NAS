""""
The main program of Pol-NAS-3 in the search stage.
"""

import os, math, copy
os.environ["CUDA_VISIBLE_DEVICES"] = "0"    # which GPU we plan to use

import numpy as np
import torch.nn as nn
import pandas as pd
from sklearn.metrics import confusion_matrix
from tqdm import tqdm
from collections import OrderedDict
from mypath import Path
from dataloaders import make_data_loader
from modeling.sync_batchnorm.replicate import patch_replication_callback
from modeling.deeplab import *
from utils.loss import SegmentationLosses
from utils.lr_scheduler import LR_Scheduler
from utils.saver import Saver
from utils.summaries import TensorboardSummary
from utils.metrics import Evaluator
from auto_deeplab import AutoDeeplab
from config_utils.search_args import obtain_search_args
from utils.copy_state_dict import copy_state_dict
import apex


try:
    from apex import amp

    APEX_AVAILABLE = True
except ModuleNotFoundError:
    APEX_AVAILABLE = False

print('torch.cuda.device_count()： ', torch.cuda.device_count())

# The function of calculating the kappa coefficient.
def kappa_coefficient(confu_matrix):
    """
    The function of calculating the kappa coefficient.
    input：
        confu_matrix：confusion matrix.
    output：
        kappa：kappa coefficient.
    """
    confu_matrix_row, confu_matrix_col = confu_matrix.shape
    Po = 0
    Pe = 0
    a = np.zeros([1, confu_matrix_row])
    b = np.zeros([1, confu_matrix_row])
    for i in range(confu_matrix_row):
        Po += confu_matrix[i, i]
        a[0, i] += confu_matrix[i, :].sum()
        b[0, i] += confu_matrix[:, i].sum()
        # print('confu_matrix[i,:].sum(): ', confu_matrix[i,:].sum())
        # print('confu_matrix[:,i].sum(): ', confu_matrix[:,i].sum())
        Pe += (a[0, i] * b[0, i])
    matrix_sum = confu_matrix.sum()
    Po /= matrix_sum
    Pe /= matrix_sum
    Pe /= matrix_sum
    # print('Po: ', Po)
    # print('Pe: ', Pe)
    kappa = (Po - Pe) / (1 - Pe)

    return kappa


print('working with pytorch version {}'.format(torch.__version__))
print('with cuda version {}'.format(torch.version.cuda))
print('cudnn enabled: {}'.format(torch.backends.cudnn.enabled))
print('cudnn version: {}'.format(torch.backends.cudnn.version()))

torch.backends.cudnn.benchmark = True


class Trainer(object):
    def __init__(self, args):
        self.args = args

        # Define Saver
        self.saver = Saver(args)
        self.saver.save_experiment_config()
        # Define Tensorboard Summary
        # self.summary = TensorboardSummary(self.saver.experiment_dir)
        # self.writer = self.summary.create_summary()
        self.use_amp = True if (APEX_AVAILABLE and args.use_amp) else False
        self.opt_level = args.opt_level

        self.weight_loss_list = args.weight_loss_list
        self.arch_loss_list = args.arch_loss_list
        self.acc_list = args.acc_list
        self.kappa_list = args.kappa_list

        kwargs = {'num_workers': args.workers, 'pin_memory': True, 'drop_last': True}
        self.train_A_loader, self.train_B_loader, self.mask_val_whole_pic, \
            self.mask_test_whole_pic, self.ground_truth, self.data_patch_loader = make_data_loader(args, **kwargs)

        if args.use_balanced_weights:
            classes_weights_path = os.path.join(Path.db_root_dir(args.dataset), args.dataset + '_classes_weights.npy')
            if os.path.isfile(classes_weights_path):
                weight = np.load(classes_weights_path)
            else:
                raise NotImplementedError
            weight = torch.from_numpy(weight.astype(np.float32))
        else:
            weight = None
        self.criterion = SegmentationLosses(weight=weight, cuda=args.cuda).build_loss(mode=args.loss_type)

        # Define network
        model = AutoDeeplab(self.args.nclass, 10, self.criterion, self.args.filter_multiplier,
                            self.args.block_multiplier, self.args.step)

        optimizer = torch.optim.SGD(
            model.weight_parameters(),
            args.lr,
            momentum=args.momentum,
            weight_decay=args.weight_decay
        )

        self.model, self.optimizer = model, optimizer

        self.architect_optimizer = torch.optim.Adam(self.model.arch_parameters(),
                                                    lr=args.arch_lr, betas=(0.9, 0.999),
                                                    weight_decay=args.arch_weight_decay)

        # Define Evaluator
        self.evaluator = Evaluator(self.args.nclass)
        self.scheduler = LR_Scheduler(args.lr_scheduler,
                                      args.lr,
                                      args.epochs,
                                      math.ceil( len(self.train_A_loader) ),
                                      min_lr=args.min_lr)
        # TODO: Figure out if len(self.train_loader) should be devided by two ? in other module as well
        # Using cuda
        if args.cuda:
            self.model = self.model.cuda()

        # mixed precision
        if self.use_amp and args.cuda:
            keep_batchnorm_fp32 = True if (self.opt_level == 'O2' or self.opt_level == 'O3') else None

            # fix for current pytorch version with opt_level 'O1'
            if self.opt_level == 'O1' and torch.__version__ < '1.3':
                for module in self.model.modules():
                    if isinstance(module, torch.nn.modules.batchnorm._BatchNorm):
                        # Hack to fix BN fprop without affine transformation
                        if module.weight is None:
                            module.weight = torch.nn.Parameter(
                                torch.ones(module.running_var.shape, dtype=module.running_var.dtype,
                                           device=module.running_var.device), requires_grad=False)
                        if module.bias is None:
                            module.bias = torch.nn.Parameter(
                                torch.zeros(module.running_var.shape, dtype=module.running_var.dtype,
                                            device=module.running_var.device), requires_grad=False)

            # print(keep_batchnorm_fp32)
            self.model, [self.optimizer, self.architect_optimizer] = amp.initialize(
                self.model, [self.optimizer, self.architect_optimizer], opt_level=self.opt_level,
                keep_batchnorm_fp32=keep_batchnorm_fp32, loss_scale="dynamic")

            print('cuda finished')

        # Using data parallel
        if args.cuda and len(self.args.gpu_ids) > 1:
            if self.opt_level == 'O2' or self.opt_level == 'O3':
                print('currently cannot run with nn.DataParallel and optimization level', self.opt_level)
            self.model = torch.nn.DataParallel(self.model, device_ids=self.args.gpu_ids)
            patch_replication_callback(self.model)
            print('training on multiple-GPUs')

        # checkpoint = torch.load(args.resume)
        # print('about to load state_dict')
        # self.model.load_state_dict(checkpoint['state_dict'])
        # print('model loaded')
        # sys.exit()

        # Resuming checkpoint
        self.best_pred = 0.0
        if args.resume is not None:
            if not os.path.isfile(args.resume):
                raise RuntimeError("=> no checkpoint found at '{}'".format(args.resume))
            checkpoint = torch.load(args.resume)
            args.start_epoch = checkpoint['epoch']

            # if the weights are wrapped in module object we have to clean it
            if args.clean_module:
                self.model.load_state_dict(checkpoint['state_dict'])
                state_dict = checkpoint['state_dict']
                new_state_dict = OrderedDict()
                for k, v in state_dict.items():
                    name = k[7:]  # remove 'module.' of dataparallel
                    new_state_dict[name] = v
                # self.model.load_state_dict(new_state_dict)
                copy_state_dict(self.model.state_dict(), new_state_dict)

            else:
                if torch.cuda.device_count() > 1 or args.load_parallel:
                    # self.model.module.load_state_dict(checkpoint['state_dict'])
                    copy_state_dict(self.model.module.state_dict(), checkpoint['state_dict'])
                else:
                    # self.model.load_state_dict(checkpoint['state_dict'])
                    copy_state_dict(self.model.state_dict(), checkpoint['state_dict'])

            if not args.ft:  # arg.ft 表示是否对网络进行 fine-tuning
                # self.optimizer.load_state_dict(checkpoint['optimizer'])
                copy_state_dict(self.optimizer.state_dict(), checkpoint['optimizer'])
            self.best_pred = checkpoint['best_pred']
            print("=> loaded checkpoint '{}' (epoch {})"
                  .format(args.resume, checkpoint['epoch']))

        # Clear start epoch if fine-tuning
        if args.ft:
            args.start_epoch = 0

    # In training_weight(), we only train the weights of current model.
    def training_weight(self, epoch):
        train_loss = 0.0
        train_total_loss = 0.0
        self.model.train()
        tbar = tqdm(self.train_A_loader)

        for itera, sample in enumerate(tbar):
            print('itera: ', itera)
            # data_patch_batch, mask_train_A_patch_batch, gt_patch_batch = sample[0][:,0:9,:,:], sample[1], sample[2]
            data_patch_batch, mask_train_A_patch_batch, gt_patch_batch = sample[0], sample[1], sample[2]
            self.scheduler(self.optimizer, itera, epoch, self.best_pred)
            self.optimizer.zero_grad()

            # data_patch_batch = torch.FloatTensor(data_patch_batch)
            gt_patch_batch = torch.LongTensor(np.array(gt_patch_batch))

            if self.args.cuda:
                data_patch_batch = data_patch_batch.cuda()
                gt_patch_batch = gt_patch_batch.cuda()

            predict = self.model.forward(data_patch_batch)

            loss = 0
            for i in range(data_patch_batch.shape[0]):
                train_A_index_tuple = np.where(mask_train_A_patch_batch[i] == True)
                if train_A_index_tuple[0].shape[0] < 1:
                    continue
                else:
                    loss += self.criterion(
                        predict[i, :, train_A_index_tuple[0], train_A_index_tuple[1]].transpose(1, 0),
                        gt_patch_batch[i, train_A_index_tuple[0], train_A_index_tuple[1]])

            if type(loss) == type(0):
                continue
            elif self.use_amp:
                with amp.scale_loss(loss, self.optimizer) as scaled_loss:
                    scaled_loss.backward()
                    # scaled_loss = scaled_loss / data_patch_batch.shape[0]
                    self.optimizer.step()
            else:
                loss.backward()
                self.optimizer.step()

            train_loss = loss.item()
            train_total_loss += train_loss
            tbar.set_description('itera: %d, Train loss: %.3f' % ((itera + 1), train_loss))

        print('[Epoch: %d, numImages: %5d]' % (epoch, itera * self.args.batch_size + data_patch_batch.shape[0]))
        print('In the process of training weights, the train_loss of last itera of an epoch: %.3f' % train_loss)
        print('In the process of training weights，the sum of train_loss in current epoch: %.3f' % train_total_loss)

        self.weight_loss_list.append(train_total_loss)

        if self.args.no_val:
            # save checkpoint every epoch
            is_best = False
            if torch.cuda.device_count() > 1:
                state_dict = self.model.module.state_dict()
            else:
                state_dict = self.model.state_dict()
            self.saver.save_checkpoint({
                'epoch': epoch,
                'state_dict': state_dict,
                'optimizer': self.optimizer.state_dict(),
                'best_pred': self.best_pred,
            }, is_best)


    # In search arch(), we only search the arch.
    def search_arch(self, epoch):
        arch_total_loss = 0.0
        self.model.train()
        tbar = tqdm(self.train_B_loader)

        for itera, sample in enumerate(tbar):
            print('itera: ', itera)
            self.architect_optimizer.zero_grad()

            # data_search_patch_batch, mask_train_B_patch_batch, gt_search_patch_batch = sample[0][:,0:9,:,:], sample[1], sample[2]
            data_search_patch_batch, mask_train_B_patch_batch, gt_search_patch_batch = sample[0], sample[1], sample[2]

            # data_search_patch_batch = torch.FloatTensor(data_search_patch_batch)
            gt_search_patch_batch = torch.LongTensor(np.array(gt_search_patch_batch))

            if self.args.cuda:
                data_search_patch_batch = data_search_patch_batch.cuda()
                gt_search_patch_batch = gt_search_patch_batch.cuda()
            predict_search = self.model.forward(data_search_patch_batch)
            loss_search = 0
            for i in range(data_search_patch_batch.shape[0]):
                train_B_index_tuple = np.where(mask_train_B_patch_batch[i] == True)
                if train_B_index_tuple[0].shape[0] < 1:
                    continue
                else:
                    loss_search += self.criterion(
                        predict_search[i, :, train_B_index_tuple[0], train_B_index_tuple[1]].transpose(1, 0),
                        gt_search_patch_batch[i, train_B_index_tuple[0], train_B_index_tuple[1]])

            if type(loss_search) == type(0):
                continue
            elif self.use_amp:
                with amp.scale_loss(loss_search, self.architect_optimizer) as arch_scaled_loss:
                    arch_scaled_loss.backward()
                    self.architect_optimizer.step()
            else:
                loss_search.backward()
                self.architect_optimizer.step()

            arch_loss = loss_search.item()
            arch_total_loss += arch_loss
            tbar.set_description('itera: %d, Arch loss: %.3f' % ((itera + 1), arch_loss))

        self.arch_loss_list.append(arch_total_loss)

    # Using val set to test the performance of current model.
    def validation(self, epoch):
        self.model.eval()
        self.evaluator.reset()

        data_patch_loader, mask_val_whole_pic, ground_truth = self.data_patch_loader, self.mask_val_whole_pic, self.ground_truth

        # ====== Calculate HEIGHT_AFTER_PAD and WIDTH_AFTER_PAD =======
        if ((self.args.height - self.args.patch_size) % self.args.stride) != 0:
            num_of_rows_padding = self.args.stride - ((self.args.height - self.args.patch_size) % self.args.stride)
            HEIGHT_AFTER_PAD = self.args.height + num_of_rows_padding
        else:
            HEIGHT_AFTER_PAD = self.args.height

        if ((self.args.width - self.args.patch_size) % self.args.stride) != 0:
            num_of_cols_padding = self.args.stride - ((self.args.width - self.args.patch_size) % self.args.stride)
            WIDTH_AFTER_PAD = self.args.width + num_of_cols_padding
        else:
            WIDTH_AFTER_PAD = self.args.width

        print('HEIGHT_AFTER_PAD: ', HEIGHT_AFTER_PAD)
        print('WIDTH_AFTER_PAD: ', WIDTH_AFTER_PAD)

        PATCH_ROW_NUM = int((HEIGHT_AFTER_PAD - self.args.patch_size) / self.args.stride + 1)
        PATCH_COL_NUM = int((WIDTH_AFTER_PAD - self.args.patch_size) / self.args.stride + 1)
        PATCH_NUM = PATCH_ROW_NUM * PATCH_COL_NUM  # the number of patches we have
        print('PATCH_NUM: ', PATCH_NUM)

        correct = 0

        with torch.no_grad():
            pred_val_total_prob = torch.zeros(
                [self.args.nclass, HEIGHT_AFTER_PAD, WIDTH_AFTER_PAD])
            add_times = torch.zeros([HEIGHT_AFTER_PAD, WIDTH_AFTER_PAD])
            ones = torch.ones([self.args.patch_size, self.args.patch_size])
            block_num = int(math.ceil(PATCH_NUM / self.args.val_batch_size))
            print('self.args.val_batch_size: ', self.args.val_batch_size)
            print('The val set contains %d parts' % block_num)

            for i, data_patch_batch in enumerate(data_patch_loader):
                data_patch_batch = data_patch_batch.cuda()
                pred_val = self.model.forward(data_patch_batch)

                # store the predicted results in matrix (pred_val_total_prob)
                for j in range(pred_val.shape[0]):
                    # the row index of current patch in the whole image
                    patch_row_index = math.floor((i * self.args.val_batch_size + j) / PATCH_COL_NUM)
                    # the col index of current patch in the whole image
                    patch_col_index = (i * self.args.val_batch_size + j) % PATCH_COL_NUM
                    pred_val_total_prob[:,patch_row_index * self.args.stride: patch_row_index * self.args.stride + self.args.patch_size, \
                        patch_col_index * self.args.stride: patch_col_index * self.args.stride + self.args.patch_size] += \
                        pred_val[j, :, :, :].cpu()
                    add_times[patch_row_index * self.args.stride: patch_row_index * self.args.stride + self.args.patch_size, \
                        patch_col_index * self.args.stride: patch_col_index * self.args.stride + self.args.patch_size] += ones

            for types_index in range(self.args.nclass):
                pred_val_total_prob[types_index, :, :] /= add_times
            pred_val_total = torch.argmax(pred_val_total_prob, dim=0)

            mask_val_whole_pic = np.array(mask_val_whole_pic, dtype=np.bool)
            ground_truth = np.array(ground_truth, dtype=np.int32)

            mask_val_whole_pic = mask_val_whole_pic.reshape([self.args.height, self.args.width])
            ground_truth = ground_truth.reshape([self.args.height, self.args.width])

            mask_val_whole_pic = mask_val_whole_pic[0:self.args.height, 0:self.args.width]
            ground_truth = ground_truth[0:self.args.height, 0:self.args.width]

            # calculate the accuracy, the confusion matrix and kappa coefficient of validation samples
            pred_val_total = pred_val_total.numpy()  # convert a torch.Tensor to a numpy.ndarray
            pred_val_total = copy.deepcopy(pred_val_total[0:self.args.height, 0:self.args.width])
            correct += (pred_val_total[mask_val_whole_pic] == ground_truth[mask_val_whole_pic]).sum().item()
            acc = float(correct) / ((mask_val_whole_pic == True).sum())
            conf_matrix = confusion_matrix(ground_truth[mask_val_whole_pic], pred_val_total[mask_val_whole_pic])
            kappa = kappa_coefficient(conf_matrix)
            print('correct: ', correct)
            print('acc: ', acc)
            print('kappa: ', kappa)
            print('(mask_val_whole_pic == True).sum(): ', (mask_val_whole_pic == True).sum())

            # ========= store some results of validation samples =========
            conf_matrix_DF = pd.DataFrame(conf_matrix)
            result_indicator_DF = pd.DataFrame(
                [acc, kappa])  # record the accuracy, kappa coefficient of validation samples
            pred_val_total_DF = pd.DataFrame(pred_val_total)
            conf_matrix_DF.to_csv('./result/search_stage/conf_matrix_' + str(epoch) + 'th_epoch.csv', index=False,
                                  header=False)
            result_indicator_DF.to_csv('./result/search_stage/result_indicator_' + str(epoch) + 'th_epoch.csv',
                                       index=False, header=False)
            pred_val_total_DF.to_csv('./result/search_stage/pred_val_total_' + str(epoch) + 'th_epoch.csv',
                                     index=False, header=False)

        print('Validation:')
        print('Epoch:{},'.format(epoch))
        print("Acc:{}, Kappa:{}, conf_matrix:{}".format(acc, kappa, conf_matrix))

        self.acc_list.append(acc)
        self.kappa_list.append(kappa)

        new_pred = acc
        if new_pred > self.best_pred:
            is_best = True
            self.best_pred = new_pred
            if torch.cuda.device_count() > 1:
                state_dict = self.model.module.state_dict()
            else:
                state_dict = self.model.state_dict()
            self.saver.save_checkpoint({
                'epoch': epoch,
                'state_dict': state_dict,
                'optimizer': self.optimizer.state_dict(),
                'best_pred': self.best_pred,
            }, is_best)

            self._alphas = state_dict['alphas']
            self._betas = state_dict['betas']
        print('self.weight_loss:\n', self.weight_loss_list)
        print('self.arch_loss:\n', self.arch_loss_list)
        print('self.acc_list:\n', self.acc_list)
        print('self.kappa_list:\n', self.kappa_list)
        max_index = self.kappa_list.index(max(self.kappa_list))
        print('max(kappa_list): ', max(self.kappa_list))
        print('max_index: ', max_index)
        print('max(kappa) corresponding acc: ', self.acc_list[max_index])

        weight_loss_list_DF = pd.DataFrame(self.weight_loss_list)
        arch_loss_list_DF = pd.DataFrame(self.arch_loss_list)
        acc_list_DF = pd.DataFrame(self.acc_list)
        kappa_list_DF = pd.DataFrame(self.kappa_list)
        weight_loss_list_DF.to_csv('./result/search_stage/weight_loss_list.csv', index=False, header=False)
        arch_loss_list_DF.to_csv('./result/search_stage/arch_loss_list.csv', index=False, header=False)
        acc_list_DF.to_csv('./result/search_stage/acc_list.csv', index=False, header=False)
        kappa_list_DF.to_csv('./result/search_stage/kappa_list.csv', index=False, header=False)


def main():
    args = obtain_search_args()
    args.cuda = not args.no_cuda and torch.cuda.is_available()
    if args.cuda:
        try:
            args.gpu_ids = [int(s) for s in args.gpu_ids.split(',')]
        except ValueError:
            raise ValueError('Argument --gpu_ids must be a comma-separated list of integers only')

    if args.sync_bn is None:
        if args.cuda and len(args.gpu_ids) > 1:
            args.sync_bn = True
        else:
            args.sync_bn = False

    # default settings for epochs, batch_size and lr
    if args.epochs is None:
        epoches = {
            'coco': 30,
            'cityscapes': 40,
            'pascal': 50,
            'kd': 10,
            'oberpfaffenhofen': 60,
            'xi_an': 40,
            'flevoland_rs2_6472_2823': 40,
            'flevoland_rs2_1618_2823': 40
        }
        args.epochs = epoches[args.dataset.lower()]

    if args.batch_size is None:
        args.batch_size = 4 * len(args.gpu_ids)

    if args.val_batch_size is None:
        print('args.val_batch_size: ', args.val_batch_size)
        args.val_batch_size = args.batch_size

    if args.checkname is None:
        args.checkname = 'deeplab-' + str(args.backbone)
    print(args)
    torch.manual_seed(args.seed)
    trainer = Trainer(args)
    print('Starting Epoch:', trainer.args.start_epoch)
    print('Total Epoches:', trainer.args.epochs)

    epoch_accumulate = 0
    for epoch in range(trainer.args.start_epoch, trainer.args.epochs):
        trainer.training_weight(epoch)
        if epoch >= args.alpha_epoch and epoch_accumulate >= (args.alpha_search_epoch_interval-1):
            trainer.search_arch(epoch)
            epoch_accumulate = -1
        epoch_accumulate += 1

        if not trainer.args.no_val and epoch % args.eval_interval == (args.eval_interval - 1):
            print('epoch: ', epoch)
            trainer.validation(epoch)


if __name__ == "__main__":
    main()

