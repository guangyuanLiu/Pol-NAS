# -*- coding: utf-8 -*-

"""
Created on 2021-02-24
@author: Liu Guangyuan

该程序实现的是 处理极化SAR地物分类问题 的 实数全卷积网络（Real Value Fully Convolutional Network， RV-FCN）中，
常用函数的程序，比如数据增强（水平、垂直翻转）。

"""

import numpy as np
import copy

def RV_FCN_data_aug(data_patch, gt_patch, mask_A_patch, mask_B_patch, lr_flip=True, ud_flip=True):
    """
    RV_FCN_data_aug is a function which aims to perform data augmentation for RV_FCN model or AutoPolFCN

    :param data_patch: data need to be augmented. A 4-D numpy.ndarray,
            [patch_num, channel_num, patch_height, patch_width].
    :param gt_patch: the ground truths of data_patch. A 3-D numpy.ndarray,
            [patch_num, patch_height, patch_width].
    :param mask_A_patch: masks(train set A) of data_patch, A 3-D numpy.ndarray, [patch_num, patch_height, patch_width].
    :param mask_B_patch: masks(train set B) of data_patch, A 3-D numpy.ndarray, [patch_num, patch_height, patch_width].
    :param lr_flip: if lr_flip == True, we will horizontally flip the data_patch,
            gt_patch, mask_A_patch and mask_B_patch.
    :param ud_flip: if ud_flip == True, we will vertically flip the data_patch,
            gt_patch, mask_A_patch and mask_B_patch.
    :return: data_patch_aug, gt_patch, mask_A_patch_aug, mask_B_patch_aug.
            i.e. augmented data_patch, gt_patch, mask_A_patch and mask_B_patch. They have the same shape
            with data_patch, gt_patch, mask_A_patch and mask_B_patch.
    """
    if lr_flip == True and ud_flip == True:
        # store the data_patch,  gt_patch, mask_A_patch and mask_B_patch that are horizontally flipped.
        data_patch_lr = np.zeros(data_patch.shape)
        gt_patch_lr = np.zeros(gt_patch.shape)
        mask_A_patch_lr = np.zeros(mask_A_patch.shape)
        mask_B_patch_lr = np.zeros(mask_B_patch.shape)

        # store the data_patch, gt_patch, mask_A_patch and mask_B_patch that are vertically flipped.
        data_patch_ud = np.zeros(data_patch.shape)
        gt_patch_ud = np.zeros(gt_patch.shape)
        mask_A_patch_ud = np.zeros(mask_A_patch.shape)
        mask_B_patch_ud = np.zeros(mask_B_patch.shape)

        # store the data_patch,  gt_patch, mask_A_patch and mask_B_patch
        # that are not only horizontally but also vertically flipped.
        # data_patch_ud_lr = np.zeros(data_patch.shape)
        # gt_patch_ud_lr = np.zeros(gt_patch.shape)
        # mask_A_patch_ud_lr = np.zeros(mask_A_patch.shape)
        # mask_B_patch_ud_lr = np.zeros(mask_B_patch.shape)

        # flip data_patch, gt_patch, mask_A_patch and mask_B_patch horizontally
        for num_idx in range(data_patch.shape[0]):
            for channel_idx in range(data_patch.shape[1]):
                data_patch_lr[num_idx, channel_idx, :, :] = copy.deepcopy(np.fliplr(data_patch[num_idx, channel_idx]))
                # print('data_patch[num_idx, channel_idx, :, :]:\n', data_patch[num_idx, channel_idx, :, :])
                # print('data_patch_lr[num_idx, channel_idx, :, :]:\n', data_patch_lr[num_idx, channel_idx, :, :])
            gt_patch_lr[num_idx, :, :] = copy.deepcopy(np.fliplr(gt_patch[num_idx,:,:]))
            mask_A_patch_lr[num_idx, :, :] = copy.deepcopy(np.fliplr(mask_A_patch[num_idx,:,:]))
            mask_B_patch_lr[num_idx, :, :] = copy.deepcopy(np.fliplr(mask_B_patch[num_idx,:,:]))

        # flip data_patch, gt_patch, mask_A_patch and mask_B_patch vertically
        for num_idx in range(data_patch.shape[0]):
            for channel_idx in range(data_patch.shape[1]):
                data_patch_ud[num_idx, channel_idx, :, :] = copy.deepcopy(np.flipud(data_patch[num_idx, channel_idx]))
                # print('data_patch[num_idx, channel_idx, :, :]:\n', data_patch[num_idx, channel_idx, :, :])
                # print('data_patch_ud[num_idx, channel_idx, :, :]:\n', data_patch_ud[num_idx, channel_idx, :, :])
            gt_patch_ud[num_idx, :, :] = copy.deepcopy(np.flipud(gt_patch[num_idx,:,:]))
            mask_A_patch_ud[num_idx, :, :] = copy.deepcopy(np.flipud(mask_A_patch[num_idx,:,:]))
            mask_B_patch_ud[num_idx, :, :] = copy.deepcopy(np.flipud(mask_B_patch[num_idx,:,:]))

        # flip data_patch, gt_patch, mask_A_patch and mask_B_patch horizontally and vertically
        # for num_idx in range(data_patch.shape[0]):
        #     for channel_idx in range(data_patch.shape[1]):
        #         data_patch_ud_lr[num_idx, channel_idx, :, :] = copy.deepcopy(
        #             np.fliplr(np.flipud(data_patch[num_idx, channel_idx])) )
        #     gt_patch_ud_lr[num_idx, :, :] = copy.deepcopy(np.fliplr(np.flipud(gt_patch[num_idx,:,:])))
        #     mask_A_patch_ud_lr[num_idx, :, :] = copy.deepcopy(np.fliplr(np.flipud(mask_A_patch[num_idx,:,:])))
        #     mask_B_patch_ud_lr[num_idx, :, :] = copy.deepcopy(np.fliplr(np.flipud(mask_B_patch[num_idx,:,:])))

        print('=== data_patch, gt_patch, mask_A_patch and mask_B_patch have been augmented. ===')
        # 水平，垂直
        data_patch_aug = np.vstack([data_patch, data_patch_lr, data_patch_ud])
        gt_patch_aug = np.vstack([gt_patch, gt_patch_lr, gt_patch_ud])
        mask_A_patch_aug = np.vstack([mask_A_patch, mask_A_patch_lr, mask_A_patch_ud])
        mask_B_patch_aug = np.vstack([mask_B_patch, mask_B_patch_lr, mask_B_patch_ud])

        # 水平，垂直，水平+垂直
        # data_patch_aug = np.vstack([data_patch, data_patch_lr, data_patch_ud, data_patch_ud_lr])
        # gt_patch_aug = np.vstack([gt_patch, gt_patch_lr, gt_patch_ud, gt_patch_ud_lr])
        # mask_A_patch_aug = np.vstack([mask_A_patch, mask_A_patch_lr, mask_A_patch_ud, mask_A_patch_ud_lr])
        # mask_B_patch_aug = np.vstack([mask_B_patch, mask_B_patch_lr, mask_B_patch_ud, mask_B_patch_ud_lr])

        return data_patch_aug, gt_patch_aug, mask_A_patch_aug, mask_B_patch_aug
    else:
        print('=== data_patch, gt_patch, mask_A_patch and mask_B_patch are NOT augmented. ===')
        return data_patch, gt_patch, mask_A_patch, mask_B_patch

# 在 train_beta2.py中使用
def RV_FCN_data_aug_train(data_patch, gt_patch, mask_AB_patch, lr_flip=True, ud_flip=True):
    """
    RV_FCN_data_aug_train is a function which aims to perform data augmentation for RV_FCN model or AutoPolFCN
        for train stage, not for search stage.

    :param data_patch: data need to be augmented. A 4-D numpy.ndarray,
            [patch_num, channel_num, patch_height, patch_width].
    :param gt_patch: the ground truths of data_patch. A 3-D numpy.ndarray,
            [patch_num, patch_height, patch_width].
    :param mask_AB_patch: masks(train set A and B) of data_patch, A 3-D numpy.ndarray, [patch_num, patch_height, patch_width].
    :param lr_flip: if lr_flip == True, we will horizontally flip the data_patch,
            gt_patch, and mask_AB_patch.
    :param ud_flip: if ud_flip == True, we will vertically flip the data_patch,
            gt_patch, and mask_AB_patch.
    :return: data_patch_aug, gt_patch, mask_AB_patch_aug.
            i.e. augmented data_patch, gt_patch, and mask_AB_patch. They have the same shape
            with data_patch, gt_patch, and mask_AB_patch.
    """
    # ============== debug用 =================
    print('data_patch.shape: ', data_patch.shape)
    print('gt_patch.shape: ', gt_patch.shape)
    print('mask_AB_patch.shape: ', mask_AB_patch.shape)
    # ========================================
    if lr_flip == True and ud_flip == True:
        # store the data_patch,  gt_patch, mask_A_patch and mask_B_patch that are horizontally flipped.
        data_patch_lr = np.zeros(data_patch.shape)
        gt_patch_lr = np.zeros(gt_patch.shape)
        mask_AB_patch_lr = np.zeros(mask_AB_patch.shape)

        # store the data_patch, gt_patch, mask_A_patch and mask_B_patch that are vertically flipped.
        data_patch_ud = np.zeros(data_patch.shape)
        gt_patch_ud = np.zeros(gt_patch.shape)
        mask_AB_patch_ud = np.zeros(mask_AB_patch.shape)

        # store the data_patch,  gt_patch, and mask_AB_patch
        # that are not only horizontally but also vertically flipped.
        # data_patch_ud_lr = np.zeros(data_patch.shape)
        # gt_patch_ud_lr = np.zeros(gt_patch.shape)
        # mask_AB_patch_ud_lr = np.zeros(mask_AB_patch.shape)

        # flip data_patch, gt_patch, and mask_AB_patch horizontally
        for num_idx in range(data_patch.shape[0]):
            for channel_idx in range(data_patch.shape[1]):
                data_patch_lr[num_idx, channel_idx, :, :] = copy.deepcopy(np.fliplr(data_patch[num_idx, channel_idx]))
            gt_patch_lr[num_idx, :, :] = copy.deepcopy(np.fliplr(gt_patch[num_idx,:,:]))
            mask_AB_patch_lr[num_idx, :, :] = copy.deepcopy(np.fliplr(mask_AB_patch[num_idx,:,:]))

        # flip data_patch, gt_patch, and mask_AB_patch vertically
        for num_idx in range(data_patch.shape[0]):
            for channel_idx in range(data_patch.shape[1]):
                data_patch_ud[num_idx, channel_idx, :, :] = copy.deepcopy(np.flipud(data_patch[num_idx, channel_idx]))
            gt_patch_ud[num_idx, :, :] = copy.deepcopy(np.flipud(gt_patch[num_idx,:,:]))
            mask_AB_patch_ud[num_idx, :, :] = copy.deepcopy(np.flipud(mask_AB_patch[num_idx,:,:]))

        # flip data_patch, gt_patch, and mask_AB_patch horizontally and vertically
        # for num_idx in range(data_patch.shape[0]):
        #     for channel_idx in range(data_patch.shape[1]):
        #         data_patch_ud_lr[num_idx, channel_idx, :, :] = copy.deepcopy(
        #             np.fliplr(np.flipud(data_patch[num_idx, channel_idx])) )
        #     gt_patch_ud_lr[num_idx, :, :] = copy.deepcopy(np.fliplr(np.flipud(gt_patch[num_idx,:,:])))
        #     mask_AB_patch_ud_lr[num_idx, :, :] = copy.deepcopy(np.fliplr(np.flipud(mask_AB_patch[num_idx,:,:])))

        print('=== data_patch, gt_patch,  and mask_AB_patch have been augmented. ===')
        # 水平，垂直
        data_patch_aug = np.vstack([data_patch, data_patch_lr, data_patch_ud])
        gt_patch_aug = np.vstack([gt_patch, gt_patch_lr, gt_patch_ud])
        mask_AB_patch_aug = np.vstack([mask_AB_patch, mask_AB_patch_lr, mask_AB_patch_ud])

        # 水平，垂直，水平+垂直
        # data_patch_aug = np.vstack([data_patch, data_patch_lr, data_patch_ud, data_patch_ud_lr])
        # gt_patch_aug = np.vstack([gt_patch, gt_patch_lr, gt_patch_ud, gt_patch_ud_lr])
        # mask_AB_patch_aug = np.vstack([mask_AB_patch, mask_AB_patch_lr, mask_AB_patch_ud, mask_AB_patch_ud_lr])

        return data_patch_aug, gt_patch_aug, mask_AB_patch_aug
    else:
        print('=== data_patch, gt_patch, and mask_AB_patch are NOT augmented. ===')
        return data_patch, gt_patch, mask_AB_patch


