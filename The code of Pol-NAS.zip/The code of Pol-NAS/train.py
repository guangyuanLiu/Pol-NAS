"""
The main program of Pol-NAS-3 in the training stage.
"""

import os, math, copy, datetime
os.environ["CUDA_VISIBLE_DEVICES"] = "0"    # which GPU we plan to use

import pdb
import warnings
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
from collections import OrderedDict

import torch
import torch.nn as nn
import torch.utils.data
import torch.backends.cudnn
import torch.optim as optim

import dataloaders
from utils.utils import AverageMeter
from utils.loss import build_criterion
from utils.step_lr_scheduler import Iter_LR_Scheduler
from retrain_model.build_autodeeplab import Retrain_Autodeeplab
from config_utils.re_train_args import obtain_retrain_Pol_NAS_args

# The function of calculating the kappa coefficient.
def kappa_coefficient(confu_matrix):
    """
    The function of calculating the kappa coefficient.
    input：
        confu_matrix：confusion matrix.
    output：
        kappa：kappa coefficient.
    """
    confu_matrix_row, confu_matrix_col = confu_matrix.shape
    Po = 0
    Pe = 0
    a = np.zeros([1, confu_matrix_row])
    b = np.zeros([1, confu_matrix_row])
    for i in range(confu_matrix_row):
        Po += confu_matrix[i,i]
        a[0,i] += confu_matrix[i,:].sum()
        b[0,i] += confu_matrix[:,i].sum()
        # print('confu_matrix[i,:].sum(): ', confu_matrix[i,:].sum())
        # print('confu_matrix[:,i].sum(): ', confu_matrix[:,i].sum())
        Pe += (a[0,i] * b[0,i])
    matrix_sum = confu_matrix.sum()
    Po /= matrix_sum
    Pe /= matrix_sum
    Pe /= matrix_sum
    # print('Po: ', Po)
    # print('Pe: ', Pe)
    kappa = (Po - Pe) / (1 - Pe)

    return kappa

def save_experiment_config(args):
    logfile = os.path.join('./result/train_stage/', 'parameters.txt')
    log_file = open(logfile, 'w')
    p = OrderedDict()
    p['dataset'] = args.dataset
    p['batch_size'] = args.batch_size
    p['test_batch_size'] = args.test_batch_size
    p['base_lr'] = args.base_lr
    p['warmup_start_lr'] = args.warmup_start_lr
    p['warmup_iters'] = args.warmup_iters
    p['min_lr'] = args.min_lr if args.min_lr is not None else 0
    p['epochs'] = args.epochs

    p['freeze_bn'] = args.freeze_bn
    p['patch_size'] = args.patch_size
    p['stride'] = args.stride
    p['data_augmentation'] = args.data_augmentation
    p['filter_multiplier'] = args.filter_multiplier
    p['step'] = args.step
    p['block_multiplier'] = args.block_multiplier
    p['use_ABN'] = args.use_ABN
    p['affine'] = args.affine
    p['criterion'] = args.criterion
    p['initial_fm'] = 128 if args.initial_fm is None else args.initial_fm
    p['lr_scheduler'] = args.mode

    for key, val in p.items():
        log_file.write(key + ':' + str(val) + '\n')
    log_file.close()

def main():
    warnings.filterwarnings('ignore')
    assert torch.cuda.is_available()
    torch.backends.cudnn.benchmark = True
    args = obtain_retrain_Pol_NAS_args()
    model_fname = './trained_model/deeplab_{0}_{1}_v3_{2}_epoch%d.pth'.format(args.backbone, args.dataset, args.exp)

    save_experiment_config(args)

    # ====== Calculate HEIGHT_AFTER_PAD and WIDTH_AFTER_PAD =======
    if ((args.height - args.patch_size) % args.stride) != 0:
        num_of_rows_padding = args.stride - ((args.height - args.patch_size) % args.stride)
        HEIGHT_AFTER_PAD = args.height + num_of_rows_padding
    else:
        HEIGHT_AFTER_PAD = args.height

    if ((args.width - args.patch_size) % args.stride) != 0:
        num_of_cols_padding = args.stride - ((args.width - args.patch_size) % args.stride)
        WIDTH_AFTER_PAD = args.width + num_of_cols_padding
    else:
        WIDTH_AFTER_PAD = args.width

    print('HEIGHT_AFTER_PAD: ', HEIGHT_AFTER_PAD)
    print('WIDTH_AFTER_PAD: ', WIDTH_AFTER_PAD)

    PATCH_ROW_NUM = int((HEIGHT_AFTER_PAD - args.patch_size) / args.stride + 1)
    PATCH_COL_NUM = int((WIDTH_AFTER_PAD - args.patch_size) / args.stride + 1)
    PATCH_NUM = PATCH_ROW_NUM * PATCH_COL_NUM  # the number of patches we have
    print('PATCH_NUM: ', PATCH_NUM)

    if args.dataset == 'pascal':
        raise NotImplementedError
    elif args.dataset == 'cityscapes':
        kwargs = {'num_workers': args.workers, 'pin_memory': True, 'drop_last': True}
        dataset_loader, num_classes = dataloaders.make_data_loader(args, **kwargs)  # 要自己改，待改 ???
        args.num_classes = num_classes
    elif args.dataset == 'oberpfaffenhofen':
    # elif args.dataset == 'flevoland_rs2_1000_1300':
    # elif args.dataset == 'sanfrancisco2':
        kwargs = {'num_workers': args.workers, 'pin_memory': True, 'drop_last': True}
        train_A_loader, mask_val_whole_pic, mask_test_whole_pic, ground_truth, data_patch_loader = dataloaders.make_data_loader(args, **kwargs)
    else:
        raise ValueError('Unknown dataset: {}'.format(args.dataset))

    if args.backbone == 'autodeeplab':
        model = Retrain_Autodeeplab(args)
    else:
        raise ValueError('Unknown backbone: {}'.format(args.backbone))

    if args.criterion == 'Ohem':
        args.thresh = 0.7
        args.crop_size = [args.crop_size, args.crop_size] if isinstance(args.crop_size, int) else args.crop_size
        args.n_min = int((args.batch_size / len(args.gpu) * args.crop_size[0] * args.crop_size[1]) // 16)
    criterion = build_criterion(args)

    # ========================== preparation before training the model ===========================
    model = nn.DataParallel(model).cuda()
    model.train()
    if args.freeze_bn:
        for m in model.modules():
            if isinstance(m, nn.BatchNorm2d):
                m.eval()
                m.weight.requires_grad = False
                m.bias.requires_grad = False
    optimizer = optim.SGD(model.module.parameters(), lr=args.base_lr, momentum=0.9, weight_decay=0.0001)
    num_iter_per_epoch = math.ceil( len(train_A_loader) )
    max_iteration = num_iter_per_epoch * args.epochs
    scheduler = Iter_LR_Scheduler(args, max_iteration, num_iter_per_epoch)
    start_epoch = 0

    if args.resume:
        if os.path.isfile(args.resume):
            print('=> loading checkpoint {0}'.format(args.resume))
            checkpoint = torch.load(args.resume)
            start_epoch = checkpoint['epoch']
            model.load_state_dict(checkpoint['state_dict'])
            optimizer.load_state_dict(checkpoint['optimizer'])
            print('=> loaded checkpoint {0} (epoch {1})'.format(args.resume, checkpoint['epoch']))
        else:
            raise ValueError('=> no checkpoint found at {0}'.format(args.resume))

    total_loss_list = []
    acc_list = []
    kappa_list = []
    best_pred = 0

    for epoch in range(start_epoch, args.epochs):
        model.train()

        total_loss = 0
        for itera, sample in enumerate(train_A_loader):
            optimizer.zero_grad()
            cur_iter = epoch * num_iter_per_epoch + itera
            scheduler(optimizer, cur_iter)

            # data_patch_batch, mask_train_A_patch_batch, gt_patch_batch = sample[0][:,0:9,:,:], sample[1], sample[2]
            data_patch_batch, mask_train_A_patch_batch, gt_patch_batch = sample[0], sample[1], sample[2]

            # data_patch_batch = torch.FloatTensor(data_patch_batch)
            gt_patch_batch = torch.LongTensor(np.array(gt_patch_batch))

            data_patch_batch = data_patch_batch.cuda()
            gt_patch_batch = gt_patch_batch.cuda()

            predict = model.forward(data_patch_batch)
            loss = 0
            for i in range(data_patch_batch.shape[0]):
                train_A_index_tuple = np.where(mask_train_A_patch_batch[i] == True)
                if train_A_index_tuple[0].shape[0] < 1:
                    continue
                else:
                    loss += criterion(
                        predict[i, :, train_A_index_tuple[0], train_A_index_tuple[1]].transpose(1, 0),
                        gt_patch_batch[i, train_A_index_tuple[0], train_A_index_tuple[1]])
            if type(loss) == type(0):
                continue
            else:
                loss.backward()
                optimizer.step()
                total_loss += loss.item()

            if np.isnan(loss.item()) or np.isinf(loss.item()):
                pdb.set_trace()
        print('epoch: {0}\t''iter: {1}/{2}\t''lr: {3:.6f}\t''loss: {4:.4f})'.format(
            epoch, itera, num_iter_per_epoch-1, scheduler.get_lr(optimizer), total_loss))

        # =========== use val set to test the performance ============
        # Training Time does not include the time of using val set to test the performance of current model for all comparison methods.
        model.eval()
        test_loss = 0.0

        correct = 0
        with torch.no_grad():
            pred_val_total_prob = torch.zeros([args.nclass, HEIGHT_AFTER_PAD, WIDTH_AFTER_PAD])
            add_times = torch.zeros([HEIGHT_AFTER_PAD, WIDTH_AFTER_PAD])
            ones = torch.ones([args.patch_size, args.patch_size])
            block_num = int(math.ceil(PATCH_NUM / args.test_batch_size))
            print('The val set contains %d parts' % block_num)

            for i, data_patch_batch in enumerate(data_patch_loader):
                data_patch_batch = data_patch_batch.cuda()
                pred_val = model.forward(data_patch_batch)

                for j in range(pred_val.shape[0]):
                    # the row index of current patch in the whole image
                    patch_row_index = math.floor((i * args.test_batch_size + j) / PATCH_COL_NUM)
                    # the col index of current patch in the whole image
                    patch_col_index = (i * args.test_batch_size + j) % PATCH_COL_NUM
                    pred_val_total_prob[:,
                        patch_row_index * args.stride: patch_row_index * args.stride + args.patch_size, \
                        patch_col_index * args.stride: patch_col_index * args.stride + args.patch_size] += pred_val[j, :,
                                                                                                       :, :].cpu()
                    add_times[patch_row_index * args.stride: patch_row_index * args.stride + args.patch_size, \
                        patch_col_index * args.stride: patch_col_index * args.stride + args.patch_size] += ones

            for types_index in range(args.nclass):
                pred_val_total_prob[types_index, :, :] /= add_times
            pred_val_total = torch.argmax(pred_val_total_prob, dim=0)

            mask_val_whole_pic = np.array(mask_val_whole_pic, dtype=np.bool)
            ground_truth = np.array(ground_truth, dtype=np.int32)

            mask_val_whole_pic = mask_val_whole_pic.reshape([args.height, args.width])
            ground_truth = ground_truth.reshape([args.height, args.width])

            mask_val_whole_pic = mask_val_whole_pic[0:args.height, 0:args.width]
            ground_truth = ground_truth[0:args.height, 0:args.width]

            # calculate the accuracy, the confusion matrix and kappa coefficient of val samples
            pred_val_total = pred_val_total.numpy()  # convert a torch.Tensor to a numpy.ndarray
            pred_val_total = copy.deepcopy(pred_val_total[0:args.height, 0:args.width])
            correct += (pred_val_total[mask_val_whole_pic] == ground_truth[mask_val_whole_pic]).sum().item()
            acc = float(correct) / ((mask_val_whole_pic == True).sum())
            conf_matrix = confusion_matrix(ground_truth[mask_val_whole_pic], pred_val_total[mask_val_whole_pic])
            kappa = kappa_coefficient(conf_matrix)
            print('correct: ', correct)
            print('acc: ', acc)
            print('kappa: ', kappa)
            print('(mask_val_whole_pic == True).sum(): ', (mask_val_whole_pic == True).sum())

        total_loss_list.append(total_loss)
        acc_list.append(acc)
        kappa_list.append(kappa)

        print('total_loss_list:\n', total_loss_list)
        print('acc_list:\n', acc_list)
        print('kappa_list:\n', kappa_list)
        print('max(kappa_list): ', max(kappa_list))
        max_index = kappa_list.index(max(kappa_list))
        print('max_index: ', max_index)
        print('max(kappa) corresponding acc: ', acc_list[max_index])

        new_pred = acc
        if new_pred > best_pred:
            torch.save(model, './result/train_stage/val_best_model.pth.tar')
            best_epoch_acc_kappa_array = np.array([epoch, acc, kappa])
            best_epoch_acc_kappa_array_DF = pd.DataFrame(best_epoch_acc_kappa_array)
            best_epoch_acc_kappa_array_DF.to_csv('./result/train_stage/val_set_best_epoch_acc_kappa.csv', index=False, header=False)
            best_pred = new_pred

    total_loss_list_DF = pd.DataFrame(total_loss_list)
    acc_list_DF = pd.DataFrame(acc_list)
    kappa_list_DF = pd.DataFrame(kappa_list)
    total_loss_list_DF.to_csv('./result/train_stage/total_loss_list.csv', index=False, header=False)
    acc_list_DF.to_csv('./result/train_stage/acc_list.csv', index=False, header=False)
    kappa_list_DF.to_csv('./result/train_stage/kappa_list.csv', index=False, header=False)

    # ======= predict the test set =======
    model = torch.load('./result/train_stage/val_best_model.pth.tar')
    if torch.cuda.is_available():
        model = model.cuda()

    model.eval()
    test_loss = 0.0

    correct = 0
    with torch.no_grad():
        pred_test_total_prob = torch.zeros([args.nclass, HEIGHT_AFTER_PAD, WIDTH_AFTER_PAD])
        add_times = torch.zeros([HEIGHT_AFTER_PAD, WIDTH_AFTER_PAD])
        ones = torch.ones([args.patch_size, args.patch_size])
        block_num = int(math.ceil(PATCH_NUM / args.test_batch_size))
        print('The test set contains %d parts' % block_num)

        for i, data_patch_batch in enumerate(data_patch_loader):
            data_patch_batch = data_patch_batch.cuda()
            pred_test = model.forward(data_patch_batch)

            # store the predicted results in matrix (pred_test_total_prob)
            for j in range(pred_test.shape[0]):
                # the row index of current patch in the whole image
                patch_row_index = math.floor((i * args.test_batch_size + j) / PATCH_COL_NUM)
                # the col index of current patch in the whole image
                patch_col_index = (i * args.test_batch_size + j) % PATCH_COL_NUM
                pred_test_total_prob[:, patch_row_index * args.stride: patch_row_index * args.stride + args.patch_size, \
                    patch_col_index * args.stride: patch_col_index * args.stride + args.patch_size] += pred_test[j, :,:,:].cpu()
                add_times[patch_row_index * args.stride: patch_row_index * args.stride + args.patch_size, \
                    patch_col_index * args.stride: patch_col_index * args.stride + args.patch_size] += ones

        for types_index in range(args.nclass):
            pred_test_total_prob[types_index, :, :] /= add_times
        pred_test_total = torch.argmax(pred_test_total_prob, dim=0)

        mask_test_whole_pic = np.array(mask_test_whole_pic, dtype=np.bool)
        ground_truth = np.array(ground_truth, dtype=np.int32)

        mask_test_whole_pic = mask_test_whole_pic.reshape([args.height, args.width])
        ground_truth = ground_truth.reshape([args.height, args.width])

        mask_test_whole_pic = mask_test_whole_pic[0:args.height, 0:args.width]
        ground_truth = ground_truth[0:args.height, 0:args.width]

        # calculate the accuracy, the confusion matrix and kappa coefficient of test samples
        pred_test_total = pred_test_total.numpy()  # convert a torch.Tensor to a numpy.ndarray
        pred_test_total = copy.deepcopy(pred_test_total[0:args.height, 0:args.width])
        correct += (pred_test_total[mask_test_whole_pic] == ground_truth[mask_test_whole_pic]).sum().item()
        acc = float(correct) / ((mask_test_whole_pic == True).sum())
        conf_matrix = confusion_matrix(ground_truth[mask_test_whole_pic], pred_test_total[mask_test_whole_pic])
        kappa = kappa_coefficient(conf_matrix)
        print('correct: ', correct)
        print('acc: ', acc)
        print('kappa: ', kappa)
        print('(mask_test_whole_pic == True).sum(): ', (mask_test_whole_pic == True).sum())

        # ========= store some results of test samples =========
        conf_matrix_DF = pd.DataFrame(conf_matrix)
        result_indicator_DF = pd.DataFrame([acc, kappa])
        pred_test_total_DF = pd.DataFrame(pred_test_total)
        conf_matrix_DF.to_csv('./result/train_stage/conf_matrix_AutoPolFCN_final.csv', index=False, header=False)
        result_indicator_DF.to_csv('./result/train_stage/result_indicator_AutoPolFCN_final.csv', index=False, header=False)
        pred_test_total_DF.to_csv('./result/train_stage/pred_test_total_AutoPolFCN_final.csv', index=False, header=False)

    # ============== predict the whole image =================
    with torch.no_grad():
        pred_total_img_prob = torch.zeros([args.nclass, HEIGHT_AFTER_PAD, WIDTH_AFTER_PAD])
        add_times = torch.zeros([HEIGHT_AFTER_PAD, WIDTH_AFTER_PAD])
        ones = torch.ones([args.patch_size, args.patch_size])
        WHOLE_PIC_BATCH_SIZE = args.test_batch_size
        block_num = int(PATCH_NUM / WHOLE_PIC_BATCH_SIZE)
        print('The whole image contains %d parts' % block_num)

        for i, data_patch_batch in enumerate(data_patch_loader):
            data_patch_batch = data_patch_batch.cuda()
            pred_total_img = model.forward(data_patch_batch)

            for j in range(pred_total_img.shape[0]):
                # the row index of current patch in the whole image
                patch_row_index = math.floor((i * WHOLE_PIC_BATCH_SIZE + j) / PATCH_COL_NUM)
                # the col index of current patch in the whole image
                patch_col_index = (i * WHOLE_PIC_BATCH_SIZE + j) % PATCH_COL_NUM
                pred_total_img_prob[:, patch_row_index * args.stride: patch_row_index * args.stride + args.patch_size, \
                    patch_col_index * args.stride: patch_col_index * args.stride + args.patch_size] += pred_total_img[j, :, :, :].cpu()
                add_times[patch_row_index * args.stride: patch_row_index * args.stride + args.patch_size, \
                    patch_col_index * args.stride: patch_col_index * args.stride + args.patch_size] += ones

        for types_index in range(args.nclass):
            pred_total_img_prob[types_index, :, :] /= add_times

        pred_total_img_total = torch.argmax(pred_total_img_prob, dim=0)
        pred_total_img_total = pred_total_img_total.numpy()  # convert a torch.Tensor to a numpy.ndarray
        pred_total_img_total = copy.deepcopy(pred_total_img_total[0:args.height, 0:args.width])

    # save the predicted results
    pred_total_img_total_DF = pd.DataFrame(pred_total_img_total)
    pred_total_img_total_DF.to_csv('./result/train_stage/pred_total_img_total.csv', index=False, header=False)
    #
    # Oberpfaffenhofen
    color = [[255,0,0], [0,190,0], [60,90,160]]    # RGB
    #
    # # Flevoland (Radarsat-2) sub image
    # color = [[15,130,60], [20,190,190], [255,0,0], [60,90,160]]       # RGB
    #
    # # San Francisco2
    # color = [[60,90,160], [0,190,0], [255,0,0], [102,102,0], [204,102,0]]      # RGB

    pred_total_color_edition = np.zeros([args.height, args.width, 3])
    #
    # color the results
    for i in range(args.height):
        for j in range(args.width):
            if pred_total_img_total[i, j] == 0:
                pred_total_color_edition[i, j, :] = color[0]
            elif pred_total_img_total[i, j] == 1:
                pred_total_color_edition[i, j, :] = color[1]
            elif pred_total_img_total[i, j] == 2:
                pred_total_color_edition[i, j, :] = color[2]
            elif pred_total_img_total[i, j] == 3:
                pred_total_color_edition[i, j, :] = color[3]
            elif pred_total_img_total[i, j] == 4:
                pred_total_color_edition[i, j, :] = color[4]
            elif pred_total_img_total[i, j] == 5:
                pred_total_color_edition[i, j, :] = color[5]
            elif pred_total_img_total[i, j] == 6:
                pred_total_color_edition[i, j, :] = color[6]
            elif pred_total_img_total[i, j] == 7:
                pred_total_color_edition[i, j, :] = color[7]
            elif pred_total_img_total[i, j] == 8:
                pred_total_color_edition[i, j, :] = color[8]
            elif pred_total_img_total[i, j] == 9:
                pred_total_color_edition[i, j, :] = color[9]
            elif pred_total_img_total[i, j] == 10:
                pred_total_color_edition[i, j, :] = color[10]
            elif pred_total_img_total[i, j] == 11:
                pred_total_color_edition[i, j, :] = color[11]
            elif pred_total_img_total[i, j] == 12:
                pred_total_color_edition[i, j, :] = color[12]
            elif pred_total_img_total[i, j] == 13:
                pred_total_color_edition[i, j, :] = color[13]
            elif pred_total_img_total[i, j] == 14:
                pred_total_color_edition[i, j, :] = color[14]

    pred_total_color_edition /= 255

    plt.imshow(pred_total_color_edition)
    plt.axis('off')
    plt.savefig('./result/train_stage/the predicted result of the whole image.tiff', bbox_inches='tight', dpi=100, pad_inches=0.0)
    plt.show()

if __name__ == "__main__":
    main()
